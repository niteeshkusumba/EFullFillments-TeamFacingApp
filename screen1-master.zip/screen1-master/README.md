# angular2-registration-login

Code was re-generated not my resource any problem Please leave me a message and allow me sometime, I will work on it.
